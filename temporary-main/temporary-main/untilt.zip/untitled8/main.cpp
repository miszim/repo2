#include <iostream>
#include <istream>

#include "main.h"




int main() {

    User user;
    std::cout<<user.getEmail();


    return 0;
}